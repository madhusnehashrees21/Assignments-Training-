﻿namespace MilitaryApp.Data
{
    public class Class1
    {

    }
}

﻿using MilitaryApp.Data;
using MilitaryApp.Domain.Entities;

Console.WriteLine("EF Core Military App started...");

using var context = new MilitaryContext();


context.Database.EnsureCreated();

GetMilitary("Before Add");


AddMilitary(context);


GetMilitary("After Add");

Console.ReadLine();

void GetMilitary(string message)
{
    var militaries = context.Militaries.ToList();
    Console.WriteLine($"{message}: Military Count = {militaries.Count}");

    foreach (var military in militaries)
    {
        Console.WriteLine(military.Name);
    }
}

void AddMilitary(MilitaryContext ctx)
{
    var military = new Military
    {
        Name = "Amit"
    };

    ctx.Militaries.Add(military);
    ctx.SaveChanges();
}
